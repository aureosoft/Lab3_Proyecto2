﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Exceptions;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace test_sms
{
    class Program
    {
        static void Main(string[] args)
        {
            // Use your account SID and authentication token instead
            // of the placeholders shown here.
            const string accountSID = "";
            const string authToken = "";

            // Initialize the TwilioClient.
            TwilioClient.Init(accountSID, authToken);

            try
            {
                // Send an SMS message.
                var message = MessageResource.Create(
                    to: new PhoneNumber(""),
                    from: new PhoneNumber("+14155992671"),
                    body: "Hola mundo esto es una prueba");
            }
            catch (TwilioException ex)
            {
                // An exception occurred making the REST call
                Console.WriteLine(ex.Message);
            }
        }
    }
}
